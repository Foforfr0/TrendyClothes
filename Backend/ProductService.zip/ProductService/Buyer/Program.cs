using Microsoft.AspNetCore.DataProtection;
using ProductBuyerService.Config;

WebApplicationBuilder? builder = WebApplication.CreateBuilder (args);

builder.Services.AddControllers ();
builder.Services.AddOpenApi ();
builder.Services.AddHttpContextAccessor ();
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor> ();
builder.Services.ConfigureBuilder (builder: builder);
builder.Services.ConfigureAuth (builder: builder);
builder.Services.AddAplicationDAOs ();
builder.Services.AddAplicationServices ();
builder.Services.AddSwaggerGen ();
builder.WebHost.UseUrls ("http://+:80");

if (!builder.Environment.IsDevelopment ()) {
    builder.Services.AddDataProtection ()
    .PersistKeysToFileSystem (new DirectoryInfo ("/var/dpkeys"))
    .SetApplicationName ("TrendyClothes");
}

WebApplication? app = builder.Build ();
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment ()) {
    app.MapOpenApi ();
    app.UseDeveloperExceptionPage ();
    app.UseSwagger ();
    app.UseSwaggerUI ();
    app.UseHttpsRedirection ();                     // Redirige autom�ticamente cualquier petici�n HTTP a HTTPS.
} else {
    app.UseExceptionHandler ("/Home/Error");
    app.UseHsts ();
}

// Middleware in correct orden: Routing -> CORS -> Auth -> Controllers.
app.UseRouting ();                              // Activa el middleware que permite enrutar las solicitudes entrantes
app.UseCors ("FromFrontend");         // Sirve para permitir o restringir solicitudes desde otros dominios 
app.UseAuthentication ();
app.UseAuthorization ();                        // Activa el middleware que revisa las pol�ticas de autorizaci�n, como [Authorize].
app.MapControllers ();                          // Habilita que se puedan mapear los endpoints de controladores con atributos [HttpGet], [Route], etc. Necesario si usas API con controladores.
app.Run ();
